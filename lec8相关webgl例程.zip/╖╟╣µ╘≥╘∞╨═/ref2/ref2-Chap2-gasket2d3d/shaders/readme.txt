gasket1v2: this versions reads in shaders from shader directory rather than including them in html file

